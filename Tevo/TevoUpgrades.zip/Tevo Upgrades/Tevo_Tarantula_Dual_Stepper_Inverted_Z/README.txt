                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2334406
Tevo Tarantula Dual Stepper Inverted Z by bitbrain is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Made for the TEVO Tarantula but can be used with any T-Slot/V-Slot extrusions. Platform height is 5mm and will work in conjunction with parts like these: https://www.thingiverse.com/thing:2039503.

I use this carriage (https://www.thingiverse.com/thing:1839201). For the original or other horizontal arrangements, see the remixes listed below.

Designed for use with 48mm Nema 17 steppers. If you use a different size motor, you may want to adjust the posts on the base sections.

The little holes on the top of the oldham couplers are to make applying lubrication easier.

The Oldham middle sections require support, the rest can print as is. Sand the oldham sliding sections to 600 grit using water paper. Also, note the way the lead screw nuts are mounted in the rendering, this stops them from butting against the flexible couplers at the lowest point.

Place 608zz bearings in the brackets to guide the Z screw.

Firmware (Marlin):

configuration.h
Set this true
\#define INVERT_Z_DIR true

configuration_adv.h
Uncomment the following
\#define Z_DUAL_STEPPER_DRIVERS

The other brackets are here: https://www.thingiverse.com/thing:2377413

If you are using the original horizontal carriage, the following remixes allow for that:
 https://www.thingiverse.com/thing:2383857
https://www.thingiverse.com/thing:2388589
https://www.thingiverse.com/thing:2408107

and for the shorter Tevo steppers this provides a bit more support:
https://www.thingiverse.com/thing:2386472