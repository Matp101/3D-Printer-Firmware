                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2557882
Control Box -Enclosure - Tevo Tarantula - MKS BASE - MOSFET by paul0 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

#Tevo Tarantula Control box with MosFet

100% tested

_ update: added the logo to glue in the top of case's logo you don't want to switch filament when printing the lid _

https://youtu.be/mubDkx7rsPQ

---

### Control Board

![](https://cdn.shopify.com/s/files/1/0663/6961/products/a1_a7a733ce-8857-4846-8625-df74d166ea69_1024x1024.jpg?v=1477412853)

###Mosfet: 
![](https://directvoltage-e7b.kxcdn.com/wp-content/uploads/2017/07/Untitled-8-1.jpg)



This Box mounts on the 40mm extrusion vertically  but with the usb facing the front of the printer.


The lid slides in from the top.
It houses the MKS Base control board and a MOSFET.

All holes are strategically  placed , the circular ones are for the black tube, the slot ones for the rest of the wires (check diagram)

It uses the stock 40mm fan to flow the air out. The air enters through the slots refreshing all the enclosure.

---

###    Print settings

> 0.2LH, 25%infill,
> \>= 4 perimeters
> \>= 4 top/bottom layers
> no supports

###Changelog:
1.1.1

- Fixed a minor missing filet on the cover
- larger M4 holes

1.1
- Corrected USB Hole
- Added some fillets on the box
- Added text tags